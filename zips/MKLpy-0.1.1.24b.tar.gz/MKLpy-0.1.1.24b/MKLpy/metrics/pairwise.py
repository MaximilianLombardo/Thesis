"""
.. codeauthor:: Ivano Lauriola <ivanolauriola@gmail.com>

================
Kernel functions
================

.. currentmodule:: MKLpy.metrics.pairwise

This module contains all kernel functions of MKLpy. These kernels can be classified in
tho classes:
* kernels used in learning phases, such as HPK as SSK;
* kernels used in evaluation, such as identity and ideal kernel.

"""

import numpy as np
from math import floor
from sklearn.metrics.pairwise import cosine_similarity

def HPK_kernel(X, T=None, degree=2):
    """performs the HPK kernel between the samples matricex *X* and *T*.
    The HPK kernel is defines as:
    .. math:: k(x,z) = \langle x,z \rangle^d

    Parameters
    ----------
    X : (n,m) array_like,
        the train samples matrix.
    T : (l,m) array_like,
        the test samples matrix. If it is not defined, then the kernel is calculated
        between *X* and *X*.

    Returns
    -------
    K : (l,n) ndarray,
        the HPK kernel matrix.
    """
    
    if degree < 1:
        raise ValueError('degree must be greather than 0')
    if degree != floor(degree):
        raise ValueError('degree must be int')
    if T==None:
        T = X
    return np.dot(X,T)**degree


def SSK_kernel(X, T=None, k=2):
    """performs the SSK kernel between the samples matricex *X* and *T*.
    Note that this is a kernel for STRINGS and text categorization.

    Parameters
    ----------
    X : (n,m) array_like,
        the train samples matrix.
    T : (l,m) array_like,
        the test samples matrix. If it is not defined, then the kernel is calculated
        between *X* and *X*.

    Returns
    -------
    K : (l,n) ndarray,
        the SSK kernel matrix.
    """
    #TODO
    return


def identity_kernel(X, T=None, s=1):
    if T is None:
        T = X
    K = (cosine_similarity(T,X) >= s*0.999999) * 1.0
    return K


def ideal_kernel(Y, Z=None):
    """performs the ideal kernel between the labels vectors *Y* and *Z*.
    The ideal kernel kernel is defines as:
    .. math:: YZ^\top

    Parameters
    ----------
    Y : (n) array_like,
        the train labels vector.
    Z : (l) array_like,
        the test labels vector. If it is not defined, then the kernel is calculated
        between *Y* and *Y*.

    Returns
    -------
    K : (l,n) ndarray,
        the ideal kernel matrix.
    """
    if z==None:
        z = y
    return np.dot(np.array([y]).T,np.array([z]))

